package com.trainingapps.userms.exceptions;

public class InvalidTokenException extends Exception{
    public  InvalidTokenException(String msg){
        super(msg);
    }
}
