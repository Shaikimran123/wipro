package com.trainingapps.muzixapp.favouritems.service;

import com.trainingapps.muzixapp.favouritems.dto.AddFavouriteRequest;
import com.trainingapps.muzixapp.favouritems.dto.FavouriteTrackDetails;
import com.trainingapps.muzixapp.favouritems.dto.RemoveFavouriteRequest;
import com.trainingapps.muzixapp.favouritems.entity.FavouriteTrack;
import com.trainingapps.muzixapp.favouritems.exception.NoTrackFoundException;
import com.trainingapps.muzixapp.favouritems.exception.TrackAlreadyExistsException;
import com.trainingapps.muzixapp.favouritems.repository.IFavouriteTrackRepository;
import com.trainingapps.muzixapp.favouritems.util.FavouriteTrackUtil;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.function.Executable;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.Mockito.*;

import java.util.List;
import java.util.Optional;


@ExtendWith(MockitoExtension.class)
class FavouriteTrackServiceImplTest {
    @Mock
    IFavouriteTrackRepository repository;
    @Mock
    FavouriteTrackUtil util;
    @InjectMocks
    @Spy
    FavouriteTrackServiceImpl service;

    /*
    Scenario: When list is successfully fetched
    input: appUserName: Sayan123
    expectation : List successfully fetched
    verifying IFavouriteTrackRepository#findByAppUserId(appUserId) is called once

     */
    @Test
    public void testListFavouriteTracksByUserName_1() throws Exception {
        String appUserName = "Sayan123";
        List<FavouriteTrackDetails> detailsList = mock(List.class);
        List<FavouriteTrack> tracks = mock(List.class);
        when(tracks.isEmpty()).thenReturn(false);
        when(repository.findByAppUserName(appUserName)).thenReturn(tracks);
        when(util.toFavouriteTrackDetails(tracks)).thenReturn(detailsList);
        List<FavouriteTrackDetails> result = service.listFavouriteTracksByUserName(appUserName);
        assertSame(detailsList, result);
        verify(repository).findByAppUserName(appUserName);
        verify(util).toFavouriteTrackDetails(tracks);


    }

    /*
    Scenario: When list is empty, NoTrackFoundException is thrown
    input: appUserName: Sayan123
    expectation : NoTrackFoundException is thrown
    verifying IFavouriteTrackRepository#findByAppUserId(appUserId) is called once

     */
    @Test
    public void testListFavouriteTracksByUserName_2() throws Exception {
        String appUserName = "Sayan123";
        List<FavouriteTrack> tracks = mock(List.class);
        when(tracks.isEmpty()).thenReturn(true);
        when(repository.findByAppUserName(appUserName)).thenReturn(tracks);
        Executable executable = () -> {
            service.listFavouriteTracksByUserName(appUserName);
        };
        /*Executable executable = new Executable() {
            @Override
            public void execute() throws Throwable {
                service.listFavouriteTracksByUserId(appUserName);
            }
        };*/
        assertThrows(NoTrackFoundException.class, executable);
        verify(repository).findByAppUserName(appUserName);

    }

    /*
    Scenario: Track is added successfully
    Input: AddFavouriteRequest data
    expectation : Track is added, favouriteTrackDetails is returned
    verify repository#save(track) is called once
    String id=generateId(requestData.getAlbumName(), requestData.getName(), requestData.getAppUserId(), requestData.getArtistName());

     */
    @Test
    public void testAddToFavourite_1() throws Exception {
        AddFavouriteRequest request = new AddFavouriteRequest();
        request.setAlbumName("Ashique 2");
        request.setName("Tum hi ho");
        request.setAppUserName("Sayan123");
        request.setArtistName("Arijit Singh");
        String id = "123";
        Optional<FavouriteTrack> optional = Optional.empty();
        when(repository.findByAppUserNameAndAlbumNameAndArtistNameAndName(request.getAppUserName(), request.getAlbumName(), request.getArtistName(), request.getName()))
                .thenReturn(optional);
        FavouriteTrack favouriteTrack = mock(FavouriteTrack.class);
        when(util.toFavouriteTrack(request)).thenReturn(favouriteTrack);
        doReturn(id).when(service).generateId(request.getAlbumName(), request.getName(), request.getAppUserName(), request.getArtistName());
        FavouriteTrack savedTrack = mock(FavouriteTrack.class);
        when(repository.save(favouriteTrack)).thenReturn(savedTrack);
        FavouriteTrackDetails details = mock(FavouriteTrackDetails.class);
        when(util.toFavouriteTrackDetails(savedTrack)).thenReturn(details);
        FavouriteTrackDetails result = service.addToFavourite(request);
        assertSame(details, result);
        verify(repository).save(favouriteTrack);

    }

    /*
    Scenario: when track already exist
    Input: AddFavouriteRequest data
    expectation : TrackAlreadyExistException is thrown
    verify repository#save(track) is never called


     */
    @Test
    public void testAddToFavourite_2() throws Exception {
        AddFavouriteRequest request = new AddFavouriteRequest();
        request.setAlbumName("Ashique 2");
        request.setName("Tum hi ho");
        request.setAppUserName("Sayan123");
        request.setArtistName("Arijit Singh");
        FavouriteTrack favouriteTrack = mock(FavouriteTrack.class);
        Optional<FavouriteTrack> optional = Optional.of(favouriteTrack);
        when(repository.findByAppUserNameAndAlbumNameAndArtistNameAndName(request.getAppUserName(), request.getAlbumName(), request.getArtistName(), request.getName()))
                .thenReturn(optional);
        Executable executable = () -> {
            service.addToFavourite(request);
        };
        assertThrows(TrackAlreadyExistsException.class, executable);
        verify(repository, never()).save(favouriteTrack);
    }

    /*
   Scenario: Track is deleted successfully
   input: RemoveFavouriteRequest requestData
   expectation : Track is successfully deleted
   verifying IFavouriteTrackRepository#delete(track) is called once

    */
    @Test
    public void testRemoveFavourite_1() throws Exception {
        RemoveFavouriteRequest request = new RemoveFavouriteRequest();
        request.setAlbumName("Ashique 2");
        request.setName("Tum hi ho");
        request.setAppUserName("Sayan123");
        request.setArtistName("Arijit Singh");
        FavouriteTrack favouriteTrack = mock(FavouriteTrack.class);
        Optional<FavouriteTrack> optional = Optional.of(favouriteTrack);
        when(repository.findByAppUserNameAndAlbumNameAndArtistNameAndName(request.getAppUserName(), request.getAlbumName(), request.getArtistName(), request.getName()))
                .thenReturn(optional);
        service.removeFavourite(request);
        verify(repository).delete(favouriteTrack);

    }

    /*
    Scenario: When track is not available, NoTrackFoundException is thrown
    input: RemoveFavouriteRequest requestData
    expectation : NoTrackFoundException is thrown
    verifying IFavouriteTrackRepository#delete(track) is never called

     */
    @Test
    public void testRemoveFavourite_2() throws Exception {
        RemoveFavouriteRequest request = new RemoveFavouriteRequest();
        request.setAlbumName("Ashique 2");
        request.setName("Tum hi ho");
        request.setAppUserName("Sayan123");
        request.setArtistName("Arijit Singh");
        FavouriteTrack favouriteTrack = mock(FavouriteTrack.class);
        Optional<FavouriteTrack> optional = Optional.empty();
        when(repository.findByAppUserNameAndAlbumNameAndArtistNameAndName(request.getAppUserName(), request.getAlbumName(), request.getArtistName(), request.getName()))
                .thenReturn(optional);
        Executable executable = () -> {
            service.removeFavourite(request);
        };
        assertThrows(NoTrackFoundException.class, executable);
        verify(repository, never()).delete(favouriteTrack);

    }


}