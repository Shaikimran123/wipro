package com.trainingapps.muzixapp.favouritems.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.trainingapps.muzixapp.favouritems.dto.AddFavouriteRequest;
import com.trainingapps.muzixapp.favouritems.dto.FavouriteTrackDetails;
import com.trainingapps.muzixapp.favouritems.dto.RemoveFavouriteRequest;
import com.trainingapps.muzixapp.favouritems.exception.NoTrackFoundException;
import com.trainingapps.muzixapp.favouritems.exception.TrackAlreadyExistsException;
import com.trainingapps.muzixapp.favouritems.service.IFavouriteTrackService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(FavouriteTrackRestApi.class)
class FavouriteTrackRestApiTest {

    private FavouriteTrackDetails response;

    @MockBean
    IFavouriteTrackService service;

    @Autowired
    MockMvc mvc;


    @BeforeEach
    public void setUp() {
        response = new FavouriteTrackDetails();
        response.setName("Tum hi ho");
        response.setAlbumName("Ashiquie 2");
        response.setArtistName("Arijit Singh");
        response.setDuration(260);
        response.setTrackUrl("#");
        response.setAlbumImageUrl("#");
    }

    @AfterEach
    public void tearDown() {
        response = null;
    }

    /**
     * scenario: When list is fetched successfully
     * input : userName=Sayan123
     * expectation: List is fetched successfully. status 200/OK
     */
    @Test
    public void testFindAll_1() throws Exception {
        String userName = "Sayan123";
        List<FavouriteTrackDetails> tracks = new ArrayList<>();
        tracks.add(response);
        when(service.listFavouriteTracksByUserName(userName)).thenReturn(tracks);
        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(tracks);
        System.out.println("**created json=" + json);
        String url = "/favouritetracks/byusername/" + userName;
        mvc.perform(get(url))
                .andExpect(status().isOk())
                .andExpect(content().json(json));


    }

    /**
     * scenario: No track is found in the favourite list
     * input : userName: Sayan123
     * expectation: NoTrackFoundException is thrown. status 404/NOT_FOUND
     */
    @Test
    public void testFindAll_2() throws Exception {
        String userName = "Sayan123";
        String msg = "No track found";
        NoTrackFoundException e = new NoTrackFoundException(msg);
        when(service.listFavouriteTracksByUserName(userName)).thenThrow(e);
        String url = "/favouritetracks/byusername/" + userName;
        mvc.perform(get(url))
                .andExpect(status().isNotFound())
                .andExpect(content().string(msg));

    }

    /**
     * scenario: When track is added successfully
     * input : AddFavouriteRequest
     * expectation:  Track is added successfully. status 200/OK
     */
    @Test
    public void testAdd_1() throws Exception {

        AddFavouriteRequest request = new AddFavouriteRequest();
        request.setAppUserName("Sayan123");
        request.setName("Tum hi ho");
        request.setAlbumName("Ashiquie 2");
        request.setArtistName("Arijit Singh");
        request.setDuration(260);
        request.setTrackUrl("#");
        request.setAlbumImageUrl("#");
        when(service.addToFavourite(request)).thenReturn(response);
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = objectMapper.writeValueAsString(request);
        String jsonResponse = objectMapper.writeValueAsString(response);
        String url = "/favouritetracks/add";
        mvc.perform(post(url)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isCreated())
                .andExpect(content().json(jsonResponse));
        verify(service).addToFavourite(request);

    }

    /**
     * scenario: When track already exists
     * input : AddFavouriteRequest
     * expectation:  TrackAlreadyExistsException is thrown. status 409/CONFLICT
     */
    @Test
    public void testAdd_2() throws Exception {

        AddFavouriteRequest request = new AddFavouriteRequest();
        request.setAppUserName("Sayan123");
        request.setName("Tum hi ho");
        request.setAlbumName("Ashiquie 2");
        request.setArtistName("Arijit Singh");
        request.setDuration(260);
        request.setTrackUrl("#");
        request.setAlbumImageUrl("#");
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = objectMapper.writeValueAsString(request);
        String msg = "Track is already in the favourite list";
        TrackAlreadyExistsException e = new TrackAlreadyExistsException(msg);
        when(service.addToFavourite(any(AddFavouriteRequest.class))).thenThrow(e);
        String url = "/favouritetracks/add";
        mvc.perform(post(url)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isConflict())
                .andExpect(content().string(msg));

    }

    /**
     * scenario: When track is removed successfully
     * input : RemovedFavouriteRequest
     * expectation:  Track is removed successfully. status 200/OK
     */
    @Test
    public void testRemove_1() throws Exception {
        RemoveFavouriteRequest request = new RemoveFavouriteRequest();
        request.setAppUserName("Sayan123");
        request.setName("Tum hi ho");
        request.setAlbumName("Ashiquie 2");
        request.setArtistName("Arijit Singh");
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = objectMapper.writeValueAsString(request);
        String url = "/favouritetracks/delete";
        mvc.perform(delete(url)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isOk());
        verify(service).removeFavourite(request);
    }

    /**
     * scenario: When track is not found
     * input : RemovedFavouriteRequest
     * expectation:  NoTrackFoundException. status 404/NOT_FOUND
     */
    @Test
    public void testRemove_2() throws Exception {
        RemoveFavouriteRequest request = new RemoveFavouriteRequest();
        request.setAppUserName("Sayan123");
        request.setName("Tum hi ho");
        request.setAlbumName("Ashiquie 2");
        request.setArtistName("Arijit Singh");
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonRequest = objectMapper.writeValueAsString(request);
        String url = "/favouritetracks/delete";
        String msg = "No track found";
        NoTrackFoundException e = new NoTrackFoundException(msg);
        doThrow(e).when(service).removeFavourite(request);
        mvc.perform(delete(url)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isNotFound())
                .andExpect(content().string(msg));
        verify(service).removeFavourite(request);
    }


}