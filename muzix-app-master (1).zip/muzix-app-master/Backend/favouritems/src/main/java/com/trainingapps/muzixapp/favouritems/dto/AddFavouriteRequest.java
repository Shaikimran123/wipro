package com.trainingapps.muzixapp.favouritems.dto;


import org.hibernate.validator.constraints.Length;
import javax.validation.constraints.NotBlank;
import java.util.Objects;

public class AddFavouriteRequest {

    @NotBlank
    @Length(min = 2, max = 30)
    private String appUserName;

    @Length(min = 2, max = 50)
    @NotBlank
    private String name;

    @NotBlank
    @Length(min = 2, max = 30)
    private String artistName;

    @NotBlank
    private String trackUrl;

    private long duration;

    @Length(min = 2, max = 50)
    @NotBlank
    private String albumName;

    @NotBlank
    private String albumImageUrl;

    public String getAppUserName() {
        return appUserName;
    }

    public void setAppUserName(String appUserName) {
        this.appUserName = appUserName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getArtistName() {
        return artistName;
    }

    public void setArtistName(String artistName) {
        this.artistName = artistName;
    }

    public String getTrackUrl() {
        return trackUrl;
    }

    public void setTrackUrl(String trackUrl) {
        this.trackUrl = trackUrl;
    }

    public long getDuration() {
        return duration;
    }

    public void setDuration(long duration) {
        this.duration = duration;
    }

    public String getAlbumName() {
        return albumName;
    }

    public void setAlbumName(String albumName) {
        this.albumName = albumName;
    }

    public String getAlbumImageUrl() {
        return albumImageUrl;
    }

    public void setAlbumImageUrl(String albumImageUrl) {
        this.albumImageUrl = albumImageUrl;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AddFavouriteRequest request = (AddFavouriteRequest) o;
        return Objects.equals(appUserName, request.appUserName) && Objects.equals(name, request.name) && Objects.equals(artistName, request.artistName) && Objects.equals(albumName, request.albumName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appUserName, name, artistName, albumName);
    }
}
