package com.trainingapps.muzixapp.favouritems.service;

import com.trainingapps.muzixapp.favouritems.dto.FavouriteTrackDetails;
import com.trainingapps.muzixapp.favouritems.dto.AddFavouriteRequest;
import com.trainingapps.muzixapp.favouritems.dto.RemoveFavouriteRequest;
import com.trainingapps.muzixapp.favouritems.entity.FavouriteTrack;
import com.trainingapps.muzixapp.favouritems.exception.NoTrackFoundException;
import com.trainingapps.muzixapp.favouritems.exception.TrackAlreadyExistsException;
import com.trainingapps.muzixapp.favouritems.repository.IFavouriteTrackRepository;
import com.trainingapps.muzixapp.favouritems.util.FavouriteTrackUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FavouriteTrackServiceImpl implements IFavouriteTrackService {
    @Autowired
    private IFavouriteTrackRepository repository;

    @Autowired
    private FavouriteTrackUtil util;


    public String generateId(String album, String track, String userName, String artist) {
        String id = album.toLowerCase() + "-" + track.toLowerCase() + "-" + artist.toLowerCase() + "-u-" + userName;
        return id;
    }

    @Override
    public FavouriteTrackDetails addToFavourite(AddFavouriteRequest requestData) throws TrackAlreadyExistsException {
        Optional<FavouriteTrack> optional = repository.findByAppUserNameAndAlbumNameAndArtistNameAndName(requestData.getAppUserName(), requestData.getAlbumName(), requestData.getArtistName(), requestData.getName());
        if (optional.isPresent()) {
            throw new TrackAlreadyExistsException("Track is already in the favourite list");
        }
        FavouriteTrack track = new FavouriteTrack();
        track = util.toFavouriteTrack(requestData);
        String id = generateId(requestData.getAlbumName(), requestData.getName(), requestData.getAppUserName(), requestData.getArtistName());
        track.setId(id);
        track = repository.save(track);
        FavouriteTrackDetails details = util.toFavouriteTrackDetails(track);
        return details;
    }

    @Override
    public void removeFavourite(RemoveFavouriteRequest requestData) throws NoTrackFoundException {
        Optional<FavouriteTrack> optional = repository.findByAppUserNameAndAlbumNameAndArtistNameAndName(requestData.getAppUserName(), requestData.getAlbumName(), requestData.getArtistName(), requestData.getName());
        if (!optional.isPresent()) {
            throw new NoTrackFoundException("No track found");
        }
        FavouriteTrack track = optional.get();
        repository.delete(track);

    }

    @Override
    public List<FavouriteTrackDetails> listFavouriteTracksByUserName(String userName) throws NoTrackFoundException {
        List<FavouriteTrack> tracks = repository.findByAppUserName(userName);
        if (tracks.isEmpty()) {
            throw new NoTrackFoundException("No track found");
        }
        List<FavouriteTrackDetails> desired = util.toFavouriteTrackDetails(tracks);
        return desired;
    }
}
