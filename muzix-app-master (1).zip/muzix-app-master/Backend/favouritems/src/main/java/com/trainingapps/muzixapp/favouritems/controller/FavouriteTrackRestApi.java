package com.trainingapps.muzixapp.favouritems.controller;

import com.trainingapps.muzixapp.favouritems.dto.FavouriteTrackDetails;
import com.trainingapps.muzixapp.favouritems.dto.AddFavouriteRequest;
import com.trainingapps.muzixapp.favouritems.dto.RemoveFavouriteRequest;
import com.trainingapps.muzixapp.favouritems.exception.NoTrackFoundException;
import com.trainingapps.muzixapp.favouritems.exception.TrackAlreadyExistsException;
import com.trainingapps.muzixapp.favouritems.service.IFavouriteTrackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin("*")
@RestController
@RequestMapping("/favouritetracks")
public class FavouriteTrackRestApi {
    @Autowired
    private IFavouriteTrackService service;


    @GetMapping("/byusername/{userName}")
    public List<FavouriteTrackDetails> findAll(@PathVariable String userName) throws NoTrackFoundException {
        List<FavouriteTrackDetails> response = service.listFavouriteTracksByUserName(userName);
        return response;
    }

    @PostMapping("/add")
    @ResponseStatus(HttpStatus.CREATED)
    public FavouriteTrackDetails add(@RequestBody AddFavouriteRequest requestData) throws TrackAlreadyExistsException {
        FavouriteTrackDetails response = service.addToFavourite(requestData);
        return response;
    }

    @DeleteMapping("/delete")
    public void remove(@RequestBody RemoveFavouriteRequest requestData) throws NoTrackFoundException {
        service.removeFavourite(requestData);

    }

}
