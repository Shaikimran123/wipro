package com.trainingapps.muzixapp.favouritems.controller;

import com.trainingapps.muzixapp.favouritems.exception.NoTrackFoundException;
import com.trainingapps.muzixapp.favouritems.exception.TrackAlreadyExistsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class CentralizedExceptionHandler {

    private static Logger logger= LoggerFactory.getLogger(CentralizedExceptionHandler.class);

    @ResponseStatus(HttpStatus.CONFLICT)
    @ExceptionHandler(TrackAlreadyExistsException.class)
    public String trackAlreadyExists(TrackAlreadyExistsException e) {
        logger.info(" Track already exists",e);
        String msg = e.getMessage();
        return msg;
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NoTrackFoundException.class)
    public String noTrackFound(NoTrackFoundException e) {
        logger.info("No track found",e);
        String msg = e.getMessage();
        return msg;
    }
}
