package com.trainingapps.muzixapp.favouritems.exception;

public class NoTrackFoundException extends Exception{
    public NoTrackFoundException(String message) {
        super(message);
    }
}
