package com.trainingapps.muzixapp.favouritems.repository;

import com.trainingapps.muzixapp.favouritems.entity.FavouriteTrack;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface IFavouriteTrackRepository extends MongoRepository<FavouriteTrack, String> {

    List<FavouriteTrack> findByAppUserName(String appUserName);


    Optional<FavouriteTrack> findByAppUserNameAndAlbumNameAndArtistNameAndName(String userName, String album, String artist, String track);

}
