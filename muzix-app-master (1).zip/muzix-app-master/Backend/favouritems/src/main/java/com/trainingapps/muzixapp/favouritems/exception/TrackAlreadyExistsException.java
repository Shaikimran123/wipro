package com.trainingapps.muzixapp.favouritems.exception;

public class TrackAlreadyExistsException extends Exception{
    public TrackAlreadyExistsException(String message) {
        super(message);
    }
}
