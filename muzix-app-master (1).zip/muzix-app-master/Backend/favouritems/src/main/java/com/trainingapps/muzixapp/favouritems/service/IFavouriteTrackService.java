package com.trainingapps.muzixapp.favouritems.service;

import com.trainingapps.muzixapp.favouritems.dto.FavouriteTrackDetails;
import com.trainingapps.muzixapp.favouritems.dto.AddFavouriteRequest;
import com.trainingapps.muzixapp.favouritems.dto.RemoveFavouriteRequest;
import com.trainingapps.muzixapp.favouritems.exception.NoTrackFoundException;
import com.trainingapps.muzixapp.favouritems.exception.TrackAlreadyExistsException;
import org.hibernate.validator.constraints.Length;
import org.springframework.validation.annotation.Validated;


import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import java.util.List;

@Validated
public interface IFavouriteTrackService {

    FavouriteTrackDetails addToFavourite(@Valid AddFavouriteRequest requestData) throws TrackAlreadyExistsException;

    void removeFavourite(@Valid RemoveFavouriteRequest requestData) throws NoTrackFoundException;

    List<FavouriteTrackDetails> listFavouriteTracksByUserName(@NotBlank @Length(min = 2, max = 30) String appUserName) throws NoTrackFoundException;


}
