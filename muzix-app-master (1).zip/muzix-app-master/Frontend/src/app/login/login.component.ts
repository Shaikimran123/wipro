import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup} from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../service/authentication.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userNameCtrl: FormControl;
  passwordCtrl: FormControl;
  myform: FormGroup;

  constructor(builder: FormBuilder, private service: AuthenticationService,private router:Router ) {
    this.userNameCtrl = builder.control('');
    this.passwordCtrl = builder.control('');
    this.myform = builder.group({
      userName: this.userNameCtrl,
      password: this.passwordCtrl
      
    });
  }

  login() {
    const userName=this.userNameCtrl.value;
    const password=this.passwordCtrl.value;
    console.log(userName);
    console.log(password);
    

    const observer={
      next:(token:string)=>{
        this.service.saveUserNameAndToken(userName,token);
        console.log(token);
        alert("Log in successful");
        this.router.navigate(['welcome']);
      },
      error:(error:Error)=>{
        alert("Couldn't log in "+error.message);
      }

    }
    const observable:Observable<string>=this.service.logIn(userName,password);
    observable.subscribe(observer);
  }
  ngOnInit(): void {
  }

}
