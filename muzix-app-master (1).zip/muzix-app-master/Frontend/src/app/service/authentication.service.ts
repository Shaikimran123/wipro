import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { baseServerUrl } from '../util/constants';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private client:HttpClient) { }

  loggedIn(): boolean {
    return this.getToken() != undefined && this.getToken() != null;
  }

  logIn(userName: string, password: string): Observable<string> {
    const url = baseServerUrl + '/login';
    const requestData = {
      userName,
      password,
    };
    const observable: Observable<string> = this.client.post(url, requestData, {
      responseType: 'text',
    });
    return observable;
  }
  register(userName: string, password: string): Observable<string> {
    const url = baseServerUrl + '/register';
    const requestData = {
      userName,
      password,
    };
    const observable: Observable<any> = this.client.post(url, requestData);
    return observable;
  }

  saveUserNameAndToken(userName: string, token: string) {
    localStorage.setItem('userName', userName);
    localStorage.setItem('token', token);
  }

  getUserName() {
    return localStorage.getItem('userName');
  }

  getToken() {
    return localStorage.getItem('token');
  }

  removeUserNameAndToken() {
    localStorage.removeItem('userName');
    localStorage.removeItem('token');
  }
}
