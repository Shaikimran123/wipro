import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AddFavouriteRequest } from '../model/addFavouriteRequest';
import { RemoveFavouriteRequest } from '../model/removeFavouriteRequest';
import { Track } from '../model/Track';
import { baseServerUrl } from '../util/constants';
import { TrackUtil } from '../util/track.util';

@Injectable({
  providedIn: 'root',
})
export class TracksService {
  constructor(private client: HttpClient) {}


  addTrack(data: any): Observable<Track> {
    const requestData: AddFavouriteRequest =
      new TrackUtil().convertToAddRequest(
        data,
        localStorage.getItem('userName')
      );
    const url = baseServerUrl+'/favouritetracks/add';
    const observable: Observable<Track> = this.client.post<AddFavouriteRequest>(
      url,
      requestData
    );
    return observable;
  }

  getAllTracks(): Observable<Track[]> {
    const url =
    baseServerUrl+'/favouritetracks/byusername/' + localStorage.getItem('userName');
    const observable: Observable<Track[]> = this.client.get<Track[]>(url);
    return observable;
  }

  deleteTrack(data: any): Observable<void> {
    const requestData: RemoveFavouriteRequest =
      new TrackUtil().convertToRemoveRequest(data, localStorage.getItem('userName'));
    const url = baseServerUrl+'/favouritetracks/delete';
    const headers = {
      body: requestData,
    };
    const observable: Observable<void> = this.client.delete<void>(url, headers);
    return observable;
  }

  getTrackFromExternalServer(album: string, artist: string): Observable<any> {
    const url = `https://ws.audioscrobbler.com/2.0/?method=album.getinfo&api_key=22e0b07f98e3ef117bfab7087178b3cf&artist=${artist}&album=${album}&format=json`;
    const observable: Observable<any> = this.client.get<any>(url);
    return observable;
  }
}
