import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from './service/authentication.service';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'contactmanagement';
  
  constructor(private service: AuthenticationService, private router:Router) {
   
  }
  
  isLoggedIn(): boolean {
    return this.service.loggedIn();
  }
  logOut() {
    alert("Successfully logged out");
    this.service.removeUserNameAndToken();
    this.router.navigate(["/login"]);
  }
}
