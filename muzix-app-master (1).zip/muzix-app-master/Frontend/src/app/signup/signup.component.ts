import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthenticationService } from '../service/authentication.service';



@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  userNameCtrl: FormControl;
  passwordCtrl: FormControl;
  myform: FormGroup;
 

  constructor(builder: FormBuilder, private service: AuthenticationService,private router:Router ) {
    this.userNameCtrl = builder.control('', [Validators.required]);
    this.passwordCtrl = builder.control('', [Validators.required]);
    this.myform = builder.group({
      userName: this.userNameCtrl,
      password: this.passwordCtrl
      
    });
  }

  register() {
    const userName=this.userNameCtrl.value;
    const password=this.passwordCtrl.value;
    console.log(userName);
    console.log(password);
    const observer={
      next:(result:any)=>{
        alert("Successfully registered");
        this.router.navigate(['login']);
      },
      error:(error:Error)=>{
        alert("Couldn't register "+error.message);
      }

    }
    const observable:Observable<any>=this.service.register(userName,password);
    observable.subscribe(observer);
    
  }

  ngOnInit(): void {
  }

}
