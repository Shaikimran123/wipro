import { AddFavouriteRequest } from '../model/addFavouriteRequest';
import { RemoveFavouriteRequest } from '../model/removeFavouriteRequest';
import { Track } from '../model/Track';

export class TrackUtil {
  convertToTrack(trackData: any): Track {
    const track: Track = new Track();
    track.name = trackData.name;
    track.duration = -1;
    if (trackData.duration) {
      track.duration = trackData.duration;
    }

    track.artistName = trackData.artist.name;
    track.trackUrl = trackData.url;
    return track;
  }
  convertToTracks(data: any): Track[] {
    const tracksData = data.album.tracks.track;
    const albumName = data.album.name;
    const albumImgUrl = data.album.image[4]['#text'];
    const desired: Track[] = [];
    for (let iterated of tracksData) {
      const track = this.convertToTrack(iterated);
      track.albumImageUrl = albumImgUrl;
      track.albumName = albumName;
      desired.push(track);
    }
    return desired;
  }

  convertToAddRequest(data: Track, userName:any): AddFavouriteRequest {
    const requestData = new AddFavouriteRequest();
    requestData.name = data.name;
    requestData.artistName = data.artistName;
    requestData.albumName = data.albumName;
    requestData.trackUrl = data.trackUrl;
    requestData.duration = data.duration;
    requestData.albumImageUrl = data.albumImageUrl;
    requestData.appUserName = userName;
    return requestData;
  }
  convertToRemoveRequest(data: Track, userName:any): RemoveFavouriteRequest {
    const requestData = new RemoveFavouriteRequest();
    requestData.name = data.name;
    requestData.artistName = data.artistName;
    requestData.albumName = data.albumName;
    requestData.appUserName = userName;
    return requestData;
  }
}
