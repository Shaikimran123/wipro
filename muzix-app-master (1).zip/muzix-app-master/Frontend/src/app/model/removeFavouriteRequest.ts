export class RemoveFavouriteRequest{
      public appUserName:string|undefined;
      public name: string|undefined;
      public artistName: string|undefined;
      public albumName: string|undefined;
      
}